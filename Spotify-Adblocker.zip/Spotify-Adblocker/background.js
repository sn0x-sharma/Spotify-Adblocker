chrome.storage.sync.set({'admuterStatus' : 'true'},function(){
	console.log('saved something')
});