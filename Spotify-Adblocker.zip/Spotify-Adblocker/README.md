## hey!! guys sn0x here 

# Spotify-Adblocker ![icon](icon16.png) [[Download]]
 Notice : This extension won't *remove* spotify's ads it will just block them. u gotta pay for no ads :)      
 
 #### Will only work on open.spotify.com          
 
 ## How To Install :

 ## 1- Download the .zip file

 ## 2- After you have downloaded it, extract it somewhere

 ## 3- Now Open Google Chrome then go to settings -> more tools -> Extension                 

 ## 4-![go to Extensions](readmeAssets/step1.png)     

 ## 5- Then enable developer option from the top-right corner     

 ## 6- Then Click on Load Unpacked button         

 ## 7- Locate and select the extracted folder like this :             
 ![select extension](readmeAssets/step2.png)    

 ## 8- And Now you are done ! it should look like this :             
 ![done](readmeAssets/step3.png)                
                    
## Preview :
![preview](readmeAssets/preview.gif)                
                    
                    
#### Sorry spotify but I would really like to listen to your ads if they weren't cringy :)
#### this project owned by sn0x all copyright are reserved.

